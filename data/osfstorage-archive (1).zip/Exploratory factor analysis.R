library(GPArotation)
library(gdata)
library(OpenMx)
library(MBESS)

# Set the working directory
d <- read.csv("EFA_data.csv", header = T)
colnames(d) <- tolower(colnames(d))
some(d)

# Store the names of the variables into separate variables
emsbnames <- c("emsb1", "emsb2", "emsb3", "emsb4", "emsb5")
imsbnames <- c("imsb1", "imsb2", "imsb3", "imsb4", "imsb5")
mpbnames <- c("empb1", "empb2", "empb3", "empb4", "empb5", "impb1", "impb2", "impb3", "impb4", "impb5", "impb6", "impb7")
imsgnames <- c("imsg1", "imsg2", "imsg3", "imsg4", "imsg5")
emsgnames <- c("emsg1", "emsg2", "emsg3", "emsg4", "emsg5")
mpgnames <- c("empg1", "empg2", "empg3", "empg4", "empg5", "impg1", "impg2", "impg3", "impg4", "impg5", "impg6", "impg7")
atbnames <- c("atb1r", "atb2", "atb3", "atb4", "atb5", "atb6", "atb7", "atb8r", "atb9", "atb10r", "atb11r", "atb12r", "atb13r", "atb14", "atb15", "atb16r", "atb17r", "atb18r", "atb19", "atb20r")
hathnames <- c("hath1r", "hath2r", "hath3", "hath4", "hath5", "hath6", "hath7r", "hath8r", "hath9r", "hath10r", "hath11r", "hath12r", "hath13", "hath14", "hath15", "hath16r", "hath17", "hath18", "hath19r", "hath20")

d <- na.omit(d[, c("ethnicity", "gender", "sex_orient", "duration", imsgnames, emsgnames, mpgnames, imsbnames, emsbnames, mpbnames, "therm_black", "therm_gay", atbnames, "atbmean", hathnames, "hathtotal")])


### Black version of the scales ###

# Select non-Black participants
db <- d[d$ethnicity != "African/ African American", ]

# Reverse code variables.  I find it strange that emsb5 was reverse-coded,
# but the correlations after reverse coding are as they're supposed to be.
# The direction of the ATB is also incorrect.
db$emsb5 <- 10 - db$emsb5
db$imsb2 <- 10 - db$imsb2
db$atbmean <- 8 - db$atbmean


prin <- princomp(db[, c(emsbnames, imsbnames, mpbnames)])
screeplot(prin, type = "lines")
summary(prin)

fact <- factanal(db[, c(emsbnames, imsbnames, mpbnames)], factors = 3, rotation = "oblimin")
fact


# Eliminating two items that have large uniquenesses; impb2 and impb7
empbnames <- c("empb1", "empb2", "empb3", "empb4", "empb5")
impbnames <- c("impb1", "impb3", "impb4", "impb5", "impb6")
mpbnames <- c("empb1", "empb2", "empb3", "empb4", "empb5", "impb1", "impb3", "impb4", "impb5", "impb6")

fact <- factanal(db[, c(emsbnames, imsbnames, mpbnames)], factors = 3, rotation = "oblimin")
fact

# Check Cronbach's alpha of the various scales
alpha(db[, emsbnames])
alpha(db[, imsbnames])
alpha(db[, impbnames])
alpha(db[, empbnames])
alpha(db[, mpbnames])
alpha(db[, atbnames])

# Find the means of the various scales
db$imsb <- rowMeans(db[, imsbnames], na.rm = T)
db$emsb <- rowMeans(db[, emsbnames], na.rm = T)
db$impb <- rowMeans(db[, impbnames], na.rm = T)
db$empb <- rowMeans(db[, empbnames], na.rm = T)
db$mpb <- rowMeans(db[, mpbnames], na.rm = T)

table(db$mpb)[1] / dim(db)[1]

# Correlation matrix, descriptives
round(cor(db[, c("mpb", "impb", "empb", "imsb", "emsb", "therm_black", "atbmean")], use = "pairwise.complete.obs"), digits = 2)
describe(db[, c("mpb", "impb", "empb", "imsb", "emsb", "therm_black", "atbmean")])


### Gay version of the scales ###
# Get the non-gay participants
dg <- d[d$sex_orient != "Homosexual/Gay/Lesbian", ]

# Reverse code ims2
dg$imsg2 <- 10 - dg$imsg2

# Principle components analysis
prin <- princomp(dg[, c(imsgnames, emsgnames, mpgnames)])
screeplot(prin, type = "lines")
summary(prin)

# Factor analysis
fact <- factanal(dg[, c(imsgnames, emsgnames, mpgnames)], factors = 3, rotation = "oblimin")
fact

# Get the good items
mpgnames <- c("empg1", "empg2", "empg3", "empg4", "empg5", "impg1", "impg3", "impg4", "impg5", "impg6")

# Repeat
fact <- factanal(dg[, c(imsgnames, emsgnames, mpgnames)], factors = 3, rotation = "oblimin")
fact

empgnames <- c("empg1", "empg2", "empg3", "empg4", "empg5")
impgnames <- c("impg1", "impg3", "impg4", "impg5", "impg6")
mpgnames <- c("empg1", "empg2", "empg3", "empg4", "empg5", "impg1", "impg3", "impg4", "impg5", "impg6")

# Cronbach's alpha
alpha(dg[, imsgnames])
alpha(dg[, emsgnames])
alpha(dg[, impgnames])
alpha(dg[, empgnames])
alpha(dg[, mpgnames])
alpha(dg[, hathnames])

# Create indices
dg$imsg <- rowMeans(dg[, imsgnames])
dg$emsg <- rowMeans(dg[, emsgnames])
dg$impg <- rowMeans(dg[, impgnames])
dg$empg <- rowMeans(dg[, empgnames])
dg$mpg <- rowMeans(dg[, mpgnames])

# Floor effect
table(dg$mpg)[1] / dim(dg)[1]

# Correlation matrix and descriptives
cor(dg[, c("mpg", "impg", "empg", "imsg", "emsg", "therm_gay", "hathtotal")])
describe(cbind(dg[, c("mpg", "impg", "empg", "imsg", "emsg", "therm_gay")], dg$hathtotal / 20))
